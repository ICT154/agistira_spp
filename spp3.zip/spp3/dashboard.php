<?php
  include('koneksi.php'); //agar index terhubung dengan database, maka koneksi sebagai penghubung harus di include
  include ('tampilan/header.php');
  include ('tampilan/sidebar.php');
  include ('tampilan/footer.php');
?>

 <!-- Main Content -->
      <div class="bg-primary main-content ">
        <section class="section">
          <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-12">
              <div class="card card-statistic-2">
                <div class="card-stats">
                  <div class="card-stats-title bg-dark">DATA KELAS -
                    <div class="dropdown d-inline">
                      <a class="font-weight-600 dropdown-toggle" data-toggle="dropdown" href="#" id="orders-month">XII RPL 2</a>
                      <ul class="dropdown-menu dropdown-menu-sm">
                        <li class="dropdown-title">Pilih Kelas</li>
                        <li><a href="kelas.php" class="dropdown-item">XII RPL 1</a></li>
                        <li><a href="kelas.php" class="dropdown-item active">XII RPL 2</a></li>
                      </ul>
                    </div>
                  </div>
                  <div class="card-stats-items">
                    <div class="card-stats-item">
                      <div class="card-stats-item-count">29</div>
                      <div class="card-stats-item-label">Siswa</div>
                    </div>
                    <div class="card-stats-item">
                      <div class="card-stats-item-count">14</div>
                      <div class="card-stats-item-label">Belum</div>
                    </div>
                    <div class="card-stats-item">
                      <div class="card-stats-item-count">15</div>
                      <div class="card-stats-item-label">Lunas</div>
                    </div>
                  </div>
                </div>
                <div class="card-icon shadow-primary bg-danger">
                  <i class="fas fa-users"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Total</h4>
                  </div>
                  <div class="card-body">
                    58
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12">
              <div class="card card-statistic-2">
                <div class="card-chart">
                  <canvas id="balance-chart" height="80"></canvas>
                </div>
                <div class="card-icon shadow-primary bg-danger">
                  <i class="fas fa-dollar-sign"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header bg-dark">
                    <h4>Pendapatan</h4>
                  </div>
                  <div class="card-body">
                    Rp 6.000.000
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12">
              <div class="card card-statistic-2">
                <div class="card-chart">
                  <canvas id="sales-chart" height="80"></canvas>
                </div>
                <div class="card-icon shadow-dark bg-danger">
                  <i class="fas fa-shopping-bag"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header bg-dark">
                    <h4>total keluar</h4>
                  </div>
                  <div class="card-body">
                    3.000,000
                  </div>
                </div>
              </div>
            </div>
          </div>
          
      <footer class="main-footer">
        <div class="footer-left">
        </div>
        </div>
      </footer>
    </div>
  </div>
</body>
