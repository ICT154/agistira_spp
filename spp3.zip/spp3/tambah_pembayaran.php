<?php
  include('koneksi.php'); //agar index terhubung dengan database, maka koneksi sebagai penghubung harus di include
  
?>
    <title>Tambah SPP</title>
  <?php
  include ('tampilan/header.php');
  include ('tambahpembayaran.php');
  include ('tampilan/footer.php');
?>